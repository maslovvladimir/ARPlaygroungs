import RealityKit
import ARKit
import PlaygroundSupport

let av = ARView()
if !ARGeoTrackingConfiguration.isSupported {
    print("geo tracking not supported")
    
}
ARGeoTrackingConfiguration.checkAvailability {
    (available, error ) in 
    guard available else {
        print("not available")
        return
    }
    print(error)
    //let arView = ARView() 
    av.session.run(ARGeoTrackingConfiguration())
}
// Create coordinates
let coordinate = CLLocationCoordinate2D(latitude: 37.795313, longitude: -122.393792)

// Create Location Anchor
let geoAnchor = ARGeoAnchor(name: "Ferry Building", coordinate: coordinate)

// Add Location Anchor to session
av.session.add(anchor: geoAnchor)

// Create a RealityKit anchor entity 
let geoAnchorEntity = AnchorEntity(anchor: geoAnchor)
PlaygroundPage.current.setLiveView(av)
