import CoreLocation
import PlaygroundSupport

// https://www.youtube.com/watch?v=Cu2QvjRt4zM

class GpsDelegate : NSObject, CLLocationManagerDelegate {
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(locations[0])
    }
    func locationManager(_ manager: CLLocationManager, 
                         didFailWithError error: Error){
        print(error.localizedDescription)
    }
    
}

PlaygroundPage.current.needsIndefiniteExecution = true


var del = GpsDelegate()
var manger: CLLocationManager? = CLLocationManager()

manger?.delegate = del
manger?.desiredAccuracy = kCLLocationAccuracyReduced
manger?.requestWhenInUseAuthorization()
//manger?.stopUpdatingLocation()
//manger?.startUpdatingLocation()
manger?.requestLocation()  
sleep(10)
