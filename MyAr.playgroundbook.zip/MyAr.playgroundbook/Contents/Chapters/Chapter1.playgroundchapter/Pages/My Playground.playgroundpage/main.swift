/*
 https://www.youtube.com/watch?v=R1XHWyprFVk
 */

import SwiftUI
import RealityKit
import PlaygroundSupport
//import SharedCode 

struct ContentView: View {
    public var body: some View {
        VStack {
            ARViewContainer()
            //ControlView()
            Text("Hello")
        }
        //.edgesIgnoringSafeArea(.all)
    }
}

struct ARViewContainer: UIViewRepresentable { 
    typealias UIViewType = ARView
    
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   ARView {
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        
        addCube(arView: arView)
        //testFunc() 
        return arView
    } 
    func updateUIView(_ uiView: ARView, context: UIViewRepresentableContext<ARViewContainer>) {}
    
}

 
 
PlaygroundPage.current.setLiveView(ContentView())


