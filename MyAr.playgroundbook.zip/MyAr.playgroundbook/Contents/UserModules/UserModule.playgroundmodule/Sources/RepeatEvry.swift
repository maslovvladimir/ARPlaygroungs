import CoreMotion
// import PlaygroundSupport

public func repeatEvery(_ seconds: TimeInterval, _ work: @escaping () -> ()) {
    work()
    DispatchQueue.main.asyncAfter(deadline: .now() + seconds) {
        repeatEvery(seconds, work)
    }
}
