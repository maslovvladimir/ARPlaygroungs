
import SwiftUI

let text = """
        Робот с управлением.

Робот упраляется жестами по экрану (swipe)
Вверх - начать движение вперед.
Вниз - движение назад
Вправо - поворот налево
Влево     - поворот направо

                            Автор: Маслов В.В
"""
struct HelpView: View {
    var body: some View {
        Text(text)
            .foregroundColor(Color.white)
            .padding(30)
            .background(Color.black.opacity(0.5))
            .border(.blue, width: 10)
            .cornerRadius(20)
        
    }
}

