
import SwiftUI

import SwiftUI
import MessageUI

struct MailView: UIViewControllerRepresentable {
    
    @Binding var isShowing: Bool
    @Binding var result: Result<MFMailComposeResult, Error>?
    @Binding var snapshot: UIImage
    @Binding var makeSnapshot: Int
    
    class Coordinator: NSObject, MFMailComposeViewControllerDelegate {
        
        @Binding var isShowing: Bool
        @Binding var result: Result<MFMailComposeResult, Error>?
        @Binding var snapshot: UIImage
        
        init(isShowing: Binding<Bool>,
             result: Binding<Result<MFMailComposeResult, Error>?>, snapshot: Binding<UIImage>) { 
            _isShowing = isShowing
            _result = result
            _snapshot = snapshot
            //print(snapshot)
        }
        
        func mailComposeController(_ controller: MFMailComposeViewController,
                                   didFinishWith result: MFMailComposeResult,
                                   error: Error?) {
            defer {
                isShowing = false
            }
            guard error == nil else {
                self.result = .failure(error!)
                return
            }
            self.result = .success(result)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator(isShowing: $isShowing,
                           result: $result, snapshot: $snapshot )
    }
    
    func makeUIViewController(context: UIViewControllerRepresentableContext<MailView>) -> MFMailComposeViewController {
        let vc = MFMailComposeViewController()
        vc.mailComposeDelegate = context.coordinator
        vc.setToRecipients(["maslovvladimir@aim.com"])
        vc.setSubject("Hello!")
        /*guard let coordinator = self.session.delegate as? ARViewCoordinator else {
         print(" error get email coordinator")
         //return  false
         }*/
        print("email")
        //print(context.coordinator.snapshot)
        let data = context.coordinator.snapshot.pngData()
        /*
         vc.setMessageBody("Hello from Califo  rnia!", isHTML: false)
         var im = UIImage(named: "IMG_0018") */
        print("makeSnapshot " + String(makeSnapshot)  )
        if makeSnapshot > 0
        {
            //let data  = im!.pngData()
            vc.addAttachmentData(data!, mimeType: "image/png", fileName: "testkover")
        }
        return vc
    }
    
    func updateUIViewController(_ uiViewController: MFMailComposeViewController,
                                context: UIViewControllerRepresentableContext<MailView>) {
        
    }
}
