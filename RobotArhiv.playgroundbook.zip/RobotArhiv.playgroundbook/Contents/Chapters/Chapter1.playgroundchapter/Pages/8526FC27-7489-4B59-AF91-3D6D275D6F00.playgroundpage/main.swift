
import SwiftUI
import MessageUI

struct ContentView: View {
    @State var isHiden = true
    @State var makeSnapshot: Int = 0
    
    @State var result: Result<MFMailComposeResult, Error>? = nil
    @State var isShowingMailView = false
    @State var snapshot: UIImage = UIImage()
    
    
    var body: some View {
        ZStack {
            ARViewContainer(makeSnapshot: $makeSnapshot, snapshot: $snapshot)  
            VStack {
                Spacer()
                if !isHiden {
                    HelpView()
                }
                Spacer()
                HStack {
                    Button("Help") {
                        isHiden = !isHiden
                    }.font(.title2) 
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 40))
                    .padding(10)
                    
                    Button("Send") { 
                        print("make photo")
                        //self.makeSnapshot = 0
                        self.isShowingMailView.toggle()
                    }.font(.title2) 
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 40))
                    .padding(10)
                    
                    Button("Shot") { 
                        print("test pressed")
                        self.makeSnapshot += 1
                        //print(self.snapshot)
                        
                    }.font(.title2) 
                    .foregroundColor(.black)
                    .padding()
                    .background(Color.white)
                    .clipShape(RoundedRectangle(cornerRadius: 40))
                    .padding(10)
                }
            }
        }
        
        .sheet(isPresented: $isShowingMailView) {
            MailView(isShowing: self.$isShowingMailView, result: self.$result, snapshot: $snapshot, makeSnapshot: self.$makeSnapshot)
        }
    }
}
