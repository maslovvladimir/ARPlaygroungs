
import SwiftUI
import SwiftUI
import RealityKit
import ARKit
import Combine
/*
 https://www.youtube.com/watch?v=cT8y7fNEMuw
 */
enum Shape: String, CaseIterable {
    case cube, sphere, model
}

class ARViewCoordinator: NSObject, ARSessionDelegate {
    var arWrapper: ARViewContainer
    @Binding var selectedShapeIndex: Int
    @Binding var snapshot : UIImage
    
    init(arWrapper: ARViewContainer, selectedShapeIndex: Binding<Int>, snapshot: Binding<UIImage> ){
        self.arWrapper = arWrapper
        self._selectedShapeIndex = selectedShapeIndex   
        self._snapshot = snapshot
    }
}

struct ARViewContainer: UIViewRepresentable { 
    @Binding var makeSnapshot: Int
    @Binding var snapshot : UIImage
    
    //typealias UIViewType = ARView
    //@Binding var selectedShapeIndex: Int   
    
    func makeCoordinator() -> ARViewCoordinator { 
        return ARViewCoordinator(arWrapper: self, selectedShapeIndex: 
                                    $makeSnapshot, snapshot: $snapshot)
    }
    
    
    
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   CustomArView {
        
        //let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        let arView = CustomArView(frame: .zero)
        
        //let modelEntity = createCube()
        let modelEntity = loadModel(name: "toy_robot_vintage", ext: "usdz")
        modelEntity?.transform.scale = SIMD3([0.05, 0.05, 0.05])
        arView.modelEntity = modelEntity
        
        let anchorEntity = AnchorEntity(plane: .horizontal)
        anchorEntity.addChild(modelEntity!)
        //let anchorEntity = ARImageAnchor()
        //let sceneAnchor = loadRealityComposerScene(filename: /"ImageTracking", fileExtension: "reality", sceneName:  "Scene2")
        
        //modelEntity.transform = textTransform()  
        //print(-90.rad())
        //anchorEntity.addChild(modelEntity)
        
        arView.scene.addAnchor(anchorEntity) 
        modelEntity!.playAnimation(modelEntity!.availableAnimations.first!.repeat())
        //
        //arView.enablePlacement()
        arView.session.delegate = context.coordinator
        
        //arView.subscribe(subs: &beginSubscribe)
        
        return arView
    } 
    func updateUIView(_ uiView: CustomArView, context: UIViewRepresentableContext<ARViewContainer>) {
        print("update arView")
        print(makeSnapshot)
        //print(context.transaction)
        if makeSnapshot > 0
        {
            uiView.snapshot(saveToHDR: false) { image in
                print(" do snapshot")
                snapshot = image!
                makeSnapshot += 1
            }
        }
    }
}

extension Double {
    func rad() -> Double {
        return Double.pi / 180.0 * self
    }
}

extension Float {
    func rad() -> Float {
        return Float.pi / 180.0 * self
    }
}
extension Int {
    func rad() -> Float {
        return Float.pi / 180.0 * Float(self)
    }
}

/*extension ARView {
 
 func subscribe (subs: inout Cancellable!){
 subs = self.scene.subscribe(
 to: SceneEvents.Update.self
 ) { event in
 print("udates begins")
 }
 }
 }*/


