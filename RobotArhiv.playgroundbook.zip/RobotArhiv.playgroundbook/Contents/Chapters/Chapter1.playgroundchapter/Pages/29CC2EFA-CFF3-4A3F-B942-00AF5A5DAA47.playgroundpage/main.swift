
import RealityKit

func AddCube (arView: ARView )
{ 
    let modelEntity = createCube()
    let anchorEntity = AnchorEntity(plane: .horizontal)
    anchorEntity.name = "CubeAnchor"
    anchorEntity.addChild(modelEntity)
    arView.scene.addAnchor(anchorEntity) 
}

func AddSphere (arView: ARView )
{ 
    let modelEntity = createSphere()
    let anchorEntity = AnchorEntity(plane: .horizontal)
    anchorEntity.name = "CubeAnchor"
    anchorEntity.addChild(modelEntity)
    arView.scene.addAnchor(anchorEntity) 
}

func createCube() -> ModelEntity {
    let mesh = MeshResource.generateBox(size: 0.2)
    let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
    let modelEntity = ModelEntity(mesh:mesh, materials: [material])
    return modelEntity
}

func createSphere() -> ModelEntity {
    let mesh = MeshResource.generateSphere(radius: 0.1)
    let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
    let modelEntity = ModelEntity(mesh:mesh, materials: [material])
    return modelEntity
}

func createText( _ text: String) -> ModelEntity {
    let mesh = MeshResource.generateText(text, extrusionDepth: 0.01, font: .systemFont(ofSize: 0.1))
    let material = SimpleMaterial(color: .white, roughness: 0.5, isMetallic: true)
    let modelEntity = ModelEntity(mesh:mesh, materials: [material])
    return modelEntity
}
