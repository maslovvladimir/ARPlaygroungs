
import SwiftUI

extension CustomArView {
    
    func enablePlacement() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func handleTap(recognizer: UITapGestureRecognizer){
        
        let location = recognizer.location(in: self)
        print(location) 
        guard let coordinator = self.session.delegate as? ARViewCoordinator else {
            print(" error get coordinator")
            return  
        }
        //var im = UIImage(named: "IMG_0018")
        //coordinator.snapshot = im!
        //print(coordinator.snapshot) 
        self.snapshot(saveToHDR: false) { image in
            print(" do snapshot")
            coordinator.snapshot = image!
            //let data = image!.pngData()
            /*guard let directory = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true) as NSURL else {
             print("error get directory")
             return 
             }
             DispatchQueue.main.async {
             let driveURL = FileManager.default.url(forUbiquityContainerIdentifier: nil) //?.appendingPathComponent("Documents")
             print(driveURL)
             }
             
             do {
             try data!.write(to: directory.appendingPathComponent("fileName.png")!)
             print("file writen")
             return 
             } catch {   
             print(error.localizedDescription)
             return 
             } */
        }
    }
}
