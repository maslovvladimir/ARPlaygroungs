
import SwiftUI
import RealityKit
import ARKit
import Combine

class CustomArView: ARView {
    var beginSubscribe: Cancellable!
    var modelEntity: Entity?
    var angle: Float = 0.0 // gradus    
    var speed: Float = 0 // 0.001 
    
    required init(frame frameRect: CGRect ) {
        super.init(frame: frameRect, cameraMode: .ar, automaticallyConfigureSession: true)
        self.isUserInteractionEnabled = true
        //enablePlacement()
        enableSwipeGesture()
        /*beginSubscribe = self.scene.subscribe(
         to: SceneEvents.Update.self
         ) { event in
         //print("udates") 
         //self.modelEntity!.position.z += 0.001
         } */
        beginSubscribe = self.scene.subscribe(to: SceneEvents.Update.self,  refreshFrame ) 
    }
    @objc required dynamic init?(coder decoder: NSCoder)
    { 
        fatalError("error init")
    } 
    
    func refreshFrame(event: SceneEvents.Update) {
        self.modelEntity!.position.z += speed * cos(angle.rad())
        self.modelEntity!.position.x += speed * sin(angle.rad()) 
        //angle += 0.01
        //self.modelEntity!.transform.rotation = simd_quatf(angle: angle, axis: simd_float3(x: 0, y: 1, z: 0))
    }
    
    func enablePlacement() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func handleTap(recognizer: UITapGestureRecognizer){
        
        let location = recognizer.location(in: self)
        print(location) 
        
    }
    
    func enableSwipeGesture() {
        let swipeGestureRecognizer = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(recognizer:))) 
        swipeGestureRecognizer.direction = .up 
        self.addGestureRecognizer(swipeGestureRecognizer)
        
        let swipeGestureRecognizer2 = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(recognizer:))) 
        swipeGestureRecognizer2.direction = .down
        self.addGestureRecognizer(swipeGestureRecognizer2)
        
        let swipeGestureRecognizer3 = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(recognizer:))) 
        swipeGestureRecognizer3.direction = .left 
        self.addGestureRecognizer(swipeGestureRecognizer3)
        
        let swipeGestureRecognizer4 = UISwipeGestureRecognizer(target: self, action: #selector(handleSwipe(recognizer:)))   
        swipeGestureRecognizer4.direction = .right
        self.addGestureRecognizer(swipeGestureRecognizer4)
    }
    
    @objc func handleSwipe(recognizer: UISwipeGestureRecognizer){
        //if recognizer.state == .ended {
        // Perform action.
        let dir = recognizer.direction
        switch dir  {
        case .up:
            print("up")
            speed = 0.001
        case .down:
            print("down")
            speed = -0.001
        case .left:
            print("left")
            angle -= 45
            modelEntity?.transform.rotation = simd_quatf(angle: angle.rad(), axis: simd_float3(x: 0, y: 1, z: 0))
        case .right:
            print("right")
            angle += 45
            modelEntity?.transform.rotation = simd_quatf(angle: angle.rad(), axis: simd_float3(x: 0, y: 1, z: 0))
        default:
            print("default")
            
        }
    }
    
}
