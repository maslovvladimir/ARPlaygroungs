

import SwiftUI
import SwiftUI
import RealityKit
import ARKit
/*
 https://www.youtube.com/watch?v=cT8y7fNEMuw
 */
public enum Shape: String, CaseIterable {
    case cube, sphere
}

public class ARViewCoordinator: NSObject, ARSessionDelegate {
    var arWrapper: ARViewContainer
    @Binding var selectedShapeIndex: Int
    
    init(arWrapper: ARViewContainer, selectedShapeIndex: Binding<Int> ){
        self.arWrapper = arWrapper
        self._selectedShapeIndex = selectedShapeIndex
        
    }
}

public struct ARViewContainer: UIViewRepresentable { 
    public typealias UIViewType = ARView
    @Binding var selectedShapeIndex: Int    
    
    public func makeCoordinator() -> ARViewCoordinator { 
        return ARViewCoordinator(arWrapper: self, selectedShapeIndex: $selectedShapeIndex)
    }
    
    
    public func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   ARView {
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        
        //AddCube(arView: arView)
        //AddModel(arView: arView, name: "chair_swan", ext: "usdz") 
        //AddModel(arView: arView, name: "toy_drummer", ext: "usdz")
        //AddModel(arView: arView, name: "Test", ext: "reality")
        //testFunc() 
        
        arView.enablePlacement()
        arView.session.delegate = context.coordinator
        return arView
    } 
    public func updateUIView(_ uiView: ARView, context: UIViewRepresentableContext<ARViewContainer>) {}
    
}    

extension ARView {
    func enablePlacement() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func createModel(shape: Shape) -> ModelEntity {
        let mesh = shape == .cube ? MeshResource.generateBox(size: 0.2) : MeshResource.generateSphere(radius: 0.1)
        let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
        return ModelEntity(mesh: mesh, materials: [material])
    }
    
    @objc func handleTap(recognizer: UITapGestureRecognizer){
        guard let coordinator = self.session.delegate as? ARViewCoordinator else {
            print(" error get coordinator")
            return
        }
        let location = recognizer.location(in: self)
        //print(location)
        let results = self.raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal)
        if let firstResult = results.first {
            let selectedShape = Shape.allCases[coordinator.selectedShapeIndex]
            //let selectedShape = Shape.allCases[0]
            //let mesh = MeshResource.generateBox(size: 0.2)
            //let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
            //let modelEntity = let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
            let modelEntity = createModel(shape: selectedShape)
            let anchorEntity = AnchorEntity(world: firstResult.worldTransform) 
            //anchorEntity.name = "CubeAnchor"
            
            /*let anchorEntity = ARAnchor(transform: simd_float4x4([  SIMD4(1,0,0,0),SIMD4(0,1,0,0),SIMD4(0,0,1,0),SIMD4(0,0,5,1)])) */
            
            anchorEntity.addChild(modelEntity)
            self.scene.addAnchor(anchorEntity) 
        } else {
            print("no surface detected")
        }
    }
}
