
import SwiftUI
import SwiftUI
import RealityKit
import ARKit
import Combine
/*
 https://www.youtube.com/watch?v=cT8y7fNEMuw
 */
enum Shape: String, CaseIterable {
    case cube, sphere, model
}

class ARViewCoordinator: NSObject, ARSessionDelegate {
    var arWrapper: ARViewContainer
    @Binding var selectedShapeIndex: Int
    
    init(arWrapper: ARViewContainer, selectedShapeIndex: Binding<Int> ){
        self.arWrapper = arWrapper
        self._selectedShapeIndex = selectedShapeIndex
        
    }
}

struct ARViewContainer: UIViewRepresentable { 
    typealias UIViewType = ARView
    @Binding var selectedShapeIndex: Int    
    //var beginSubscribe: Cancellable!
    
    func makeCoordinator() -> ARViewCoordinator { 
        return ARViewCoordinator(arWrapper: self, selectedShapeIndex: $selectedShapeIndex)
    }
    
    func textTransform() -> Transform {
        let rotX = simd_quatf(angle: -90.rad(), axis: simd_float3(x: 1, y: 0, z: 0))
        let rotY = simd_quatf(angle: -90.rad(), axis: simd_float3(x: 0, y: 1, z: 0))
        let rotZ = simd_quatf(angle: 90.rad(), axis: simd_float3(x: 0, y: 0, z: 1))
        var rm1 = Transform()
        rm1.rotation = rotX
        var rm2 = Transform()
        rm2.rotation = rotY
        return Transform(matrix:rm1.matrix * rm2.matrix)
    }
    
    
    func makeUIView(context: UIViewRepresentableContext<ARViewContainer>) ->   ARView {
        let arView = ARView(frame: .zero, cameraMode: .ar, automaticallyConfigureSession: true)
        
        //let modelEntity = createText( "Привет народ!") 
        // let modelEntity = loadModel(name: "toy_drummer", ext: "usdz")
        //let anchorEntity = AnchorEntity(plane: .vertical)
        //let anchorEntity = ARImageAnchor()
        let sceneAnchor = loadRealityComposerScene(filename: "ImageTracking", fileExtension: "reality", sceneName:  "Scene2")
        
        //modelEntity.transform = textTransform()  
        //print(-90.rad())
        //anchorEntity.addChild(modelEntity)
        if let anchor = sceneAnchor {
            arView.scene.addAnchor(anchor)
        }
        //arView.scene.addAnchor(sceneAnchor!) 
        
        //AddCube(arView: arView)
        //AddSphere(arView: arView)
        //AddModel(arView: arView, name: "chair_swan", ext: "usdz") 
        //AddModel(arView: arView, name: "toy_drummer", ext: "usdz")
        //AddModel(arView: arView, name: "Test", ext: "reality")
        //testFunc() 
        //AddModel2(arView: arView, name: "toy_drummer", ext: "usdz")
        //AddScene(arView: arView, name: "toy_drummer", ext: "usdz")
        
        //arView.enablePlacement()
        //arView.session.delegate = context.coordinator
        
        /*beginSubscribe = arView.scene.subscribe(
         to: SceneEvents.Update.self
         ) { event in
         print("udates begins")
         }*/
        
        return arView
    } 
    func updateUIView(_ uiView: ARView, context: UIViewRepresentableContext<ARViewContainer>) {}
    
}

extension Double {
    func rad() -> Double {
        return Double.pi / 180.0 * self
    }
}

extension Float {
    func rad() -> Float {
        return Float.pi / 180.0 * self
    }
}
extension Int {
    func rad() -> Float {
        return Float.pi / 180.0 * Float(self)
    }
}
