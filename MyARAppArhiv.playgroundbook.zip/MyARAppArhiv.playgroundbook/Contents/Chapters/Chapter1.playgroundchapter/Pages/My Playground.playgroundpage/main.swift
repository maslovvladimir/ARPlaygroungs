
import SwiftUI

struct ContentView: View {
    
    let objectShapes = Shape.allCases
    
    @State private var selectedShapeIndex = 0
    
    var body: some View {
        ZStack(alignment: .bottomTrailing) { 
            ARViewContainer(selectedShapeIndex: $selectedShapeIndex)
            Picker("Shapes", selection: $selectedShapeIndex) { 
                ForEach(0..<objectShapes.count){
                    index in
                    Text(self.objectShapes[index].rawValue).tag(index)
                }
            }.pickerStyle(SegmentedPickerStyle() )
            .padding(10)
            .background(Color.black.opacity(0.5))
        }
        
        /*VStack {
         Image(systemName: "globe")
         .imageScale(.large)
         .foregroundColor(.accentColor)
         Text("Hello, world!")
         } */
    }
}
