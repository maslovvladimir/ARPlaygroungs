
import SwiftUI
import ARKit 
import RealityKit

extension ARView {
    func enablePlacement() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(handleTap(recognizer:)))
        self.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func createModel(arView: ARView, shape: Shape, result: ARRaycastResult)  {
        let material = SimpleMaterial(color: .blue, roughness: 0.5, isMetallic: true)
        let anchorEntity = AnchorEntity(world: result.worldTransform) 
        
        
        switch shape {
        case .cube: 
            //let mesh = MeshResource.generateBox(size: 0.2) 
            //return ModelEntity(mesh: mesh, materials: [material])
            let modelEntity = createCube()
            anchorEntity.addChild(modelEntity)
            arView.scene.addAnchor(anchorEntity) 
            
        case .sphere:
            let modelEntity = createSphere()
            anchorEntity.addChild(modelEntity)
            arView.scene.addAnchor(anchorEntity) 
            
        case .model:
            let model = loadModel(name: "toy_drummer", ext: "usdz")
            let scale = SIMD3<Float>([0.03, 0.03, 0.03])
            model!.transform.scale =  scale
            anchorEntity.addChild(model!)
            arView.scene.addAnchor(anchorEntity) 
            model!.playAnimation(model!.availableAnimations.first!.repeat())
        }
    }
    
    @objc func handleTap(recognizer: UITapGestureRecognizer){
        guard let coordinator = self.session.delegate as? ARViewCoordinator else {
            print(" error get coordinator")
            return
        }
        let location = recognizer.location(in: self)
        //print(location)
        let results = self.raycast(from: location, allowing: .estimatedPlane, alignment: .horizontal)
        if let firstResult = results.first {
            let selectedShape = Shape.allCases[coordinator.selectedShapeIndex]
            
            createModel(arView: self, shape: selectedShape, result: firstResult)
            
        } else {
            print("no surface detected")
        }
    }
}
