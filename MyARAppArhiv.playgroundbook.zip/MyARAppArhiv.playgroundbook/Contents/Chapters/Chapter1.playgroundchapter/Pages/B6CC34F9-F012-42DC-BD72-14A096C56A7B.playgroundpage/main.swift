
import RealityKit
import Foundation
//DispatchQueue.main.async {

func AddModel (arView: ARView, name: String, ext: String)
{
    //let docsUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    //let fileUrl = docsUrl.appendingPathComponent(url!.lastPathComponent)
    //let fileUrl = docsUrl.appendingPathComponent("chair_swan.usdz") 
    let url = Bundle.main.url(forResource: name, withExtension: ext)!
    //print(fileUrl )
    do {
        let modelEntity = try ModelEntity.load(contentsOf: url)
        let anchorEntity = AnchorEntity(plane: .horizontal)
        anchorEntity.addChild(modelEntity)
        arView.scene.addAnchor(anchorEntity) 
        modelEntity.playAnimation(modelEntity.availableAnimations.first!.repeat())
    } catch {
        print(error.localizedDescription)
    }
}

func AddModel2 (arView: ARView, name: String, ext: String)
{
    let modelEntity = loadModel(name: name, ext: ext)
    let anchorEntity = AnchorEntity(plane: .horizontal)
    anchorEntity.addChild(modelEntity!)
    arView.scene.addAnchor(anchorEntity)
    guard let model = modelEntity else {return}
    model.playAnimation(model.availableAnimations.first!.repeat())
    
}

func loadModel(name: String, ext: String) -> Entity? {
    let url = Bundle.main.url(forResource: name, withExtension: ext)!
    //print(fileUrl )
    do {
        let modelEntity = try ModelEntity.load(contentsOf: url)
        return modelEntity
        //modelEntity.playAnimation(modelEntity.availableAnimations.first!.repeat())
    } catch {
        print(error.localizedDescription)
    }
    return nil
}

func AddScene (arView: ARView, name: String, ext: String)
{
    
    let url = Bundle.main.url(forResource: name, withExtension: ext)!
    //print(fileUrl )
    do {  
        //let modelEntity = try Entity.load(contentsOf: url)
        let loadedAnchor = try? Entity.loadAnchor(contentsOf: url)
        
        let animations = loadedAnchor!.availableAnimations
        
        //print(animations?.count)
        //let anchorEntity = AnchorEntity(plane: .horizontal)
        //anchorEnti  ty.addChild(modelEntity)  
        if let anim = animations.first {
            loadedAnchor!.playAnimation(anim.repeat()) 
        }
        //let anchorEntity = AnchorEntity(plane: .horizontal)
        //anchorEntity.addChild(modelEntity)
        arView.scene.addAnchor(loadedAnchor!) 
    } catch {
        print(error.localizedDescription)
    }
}

func createRealityURL(filename: String, 
                      fileExtension: String, 
                      sceneName:String) -> URL? {
    // Create a URL that points to the specified Reality file. 
    guard let realityFileURL = Bundle.main.url(forResource: filename, 
                                               withExtension: fileExtension) else {
        print("Error finding Reality file \(filename).\(fileExtension)")
        return nil
    }
    
    // Append the scene name to the URL to point to 
    // a single scene within the file.
    let realityFileSceneURL = realityFileURL.appendingPathComponent(sceneName, 
                                                                    isDirectory: false)
    return realityFileSceneURL
}

func loadRealityComposerScene (filename: String,
                               fileExtension: String,
                               sceneName: String) -> (Entity & HasAnchoring)? {
    guard let realitySceneURL = createRealityURL(filename: filename,
                                                 fileExtension: fileExtension,
                                                 sceneName: sceneName) else {
        return nil
    }
    let loadedAnchor = try? Entity.loadAnchor(contentsOf: realitySceneURL)
    
    return loadedAnchor
}
